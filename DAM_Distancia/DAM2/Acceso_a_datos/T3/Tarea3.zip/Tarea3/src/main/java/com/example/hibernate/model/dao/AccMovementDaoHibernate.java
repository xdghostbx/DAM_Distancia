package com.example.hibernate.model.dao;

import com.example.hibernate.model.AccMovement;
import com.example.hibernate.model.util.GenericDaoHibernate;


public class AccMovementDaoHibernate extends GenericDaoHibernate<AccMovement, Integer> implements IAccMovementDao {

    public AccMovementDaoHibernate() {
        super();
    }
}
