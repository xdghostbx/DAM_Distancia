use empresa;
INSERT INTO PROJECT (PROJNAME) VALUES 
('Desenvolvemento de Software Libre'),
('Inteligencia Artificial para Empresas'),
('Plataforma de Comercio Electrónico'),
('Seguridade Informática Avanzada'),
('Automatización con Internet das Cousas');


INSERT INTO PROJECT_EMP (PROJECTNO, EMPNO) VALUES 
-- Primeiro proxecto: Desenvolvemento de Software Libre
(1, 7369), (1, 7566), (1, 7788), 

-- Segundo proxecto: Intelixencia Artificial para Empresas
(2, 7521), (2, 7839), (2, 7902), 

-- Terceiro proxecto: Plataforma de Comercio Electrónico
(3, 7654), (3, 7499), (3, 7782), 

-- Cuarto proxecto: Seguridade Informática Avanzada
(4, 7698), (4, 7844), 

-- Quinto proxecto: Automatización con Internet das Cousas
(5, 7876), (5, 7934);

