-- Select the database only if it doesn't already exist
CREATE DATABASE IF NOT EXISTS empresa;