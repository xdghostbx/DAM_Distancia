package com.example.hibernate.model.servicio;

import com.example.hibernate.model.Empleado;

public interface IEmpleadoServicio {
   public Empleado find(Integer empno);

  
}
