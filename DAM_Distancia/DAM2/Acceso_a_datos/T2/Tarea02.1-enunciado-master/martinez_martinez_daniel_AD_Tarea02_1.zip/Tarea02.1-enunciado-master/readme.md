Para cambiar entre un sistema xestor de bd e outro, hai que ...

no arquivo db.properties hai que cambiar o encabezado 

SELECTED_SGBD=SQLSERVER


E poñer o gestor de bases de datos que imos a usar. De engadir máis gestores
habría que engadir tamén os properties de dito gestor
Tamén hai que engadir o jar na carpeta lib do proxecto (a demáis das dependencias)